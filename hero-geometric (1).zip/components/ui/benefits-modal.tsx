"use client"

import { useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X } from "lucide-react"

interface BenefitItem {
  icon: string
  title: string
  description: string
}

interface BenefitsModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  description: string
  benefits: BenefitItem[]
}

export function BenefitsModal({ isOpen, onClose, title, description, benefits }: BenefitsModalProps) {
  // Prevent scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "auto"
    }
    return () => {
      document.body.style.overflow = "auto"
    }
  }, [isOpen])

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[1001] flex items-center justify-center bg-black/50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
          >
            <div className="flex justify-between items-center p-5 border-b bg-primary text-white">
              <h3 className="text-xl font-semibold">{title}</h3>
              <button onClick={onClose} className="text-white hover:text-gray-200 transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="p-6 overflow-y-auto">
              <p className="text-gray-600 mb-8">{description}</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {benefits.map((benefit, index) => (
                  <div
                    key={index}
                    className="bg-gray-50 p-5 rounded-lg border border-gray-100 hover:shadow-md transition-shadow"
                  >
                    <div className="text-3xl mb-3">{benefit.icon}</div>
                    <h4 className="text-lg font-semibold text-primary mb-2">{benefit.title}</h4>
                    <p className="text-gray-600 text-sm">{benefit.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 border-t bg-gray-50 flex justify-end">
              <button
                onClick={onClose}
                className="bg-secondary hover:bg-[#234e39] text-white px-4 py-2 rounded font-medium text-sm transition-colors"
              >
                Cerrar
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}

