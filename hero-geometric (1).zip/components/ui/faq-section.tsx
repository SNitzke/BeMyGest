interface FAQItem {
  question: string
  answer: string
}

// Actualizar la interfaz FAQSectionProps
interface FAQSectionProps {
  title: string
  description: string
  faqs: FAQItem[]
  id?: string
}

// Actualizar la función para usar el id
export function FAQSection({ title, description, faqs, id }: FAQSectionProps) {
  return (
    <section id={id} className="py-24 bg-gray-50">
      <div className="container mx-auto px-5">
        <h2 className="text-3xl font-semibold text-gray-800 mb-4">{title}</h2>
        <p className="text-gray-600 mb-8">{description}</p>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-medium text-gray-700 mb-2">{faq.question}</h3>
              <p className="text-gray-500">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

