"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface HeroProps {
  onStartNowClick: () => void
}

export const Hero = ({ onStartNowClick }: HeroProps) => {
  return (
    <section className="hero pt-28">
      <div className="container mx-auto px-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-center md:text-left"
          >
            <h1 className="text-5xl font-bold text-primary mb-6">Gestión de Alquileres Simplificada</h1>
            <p className="text-lg text-neutral mb-8">
              BeMyGest es la solución integral que conecta a propietarios e inquilinos, simplificando pagos, reportes de
              problemas y comunicación. Gestiona tus propiedades o alquileres de manera eficiente, ahorrando tiempo y
              reduciendo el estrés.
            </p>
            <button
              onClick={onStartNowClick}
              className="bg-secondary hover:bg-[#234e39] text-white px-6 py-3 rounded font-semibold text-sm tracking-wide transition-colors inline-block"
            >
              Comenzar Ahora
            </button>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative h-[400px]"
          >
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_SHB4ZsHT_1741019088652_raw.jpg-gMiUKJ04Nu7mFsDIYfHAJMqPzIBiGb.jpeg"
              alt="BeMyGest Dashboard"
              fill
              className="object-cover rounded-lg shadow-xl"
              priority
            />
          </motion.div>
        </div>
      </div>
    </section>
  )
}

