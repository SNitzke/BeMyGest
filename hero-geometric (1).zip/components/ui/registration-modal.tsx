"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Loader2 } from "lucide-react"
import { sendContactEmail } from "@/app/actions/email-actions"

interface RegistrationModalProps {
  isOpen: boolean
  onClose: () => void
  source?: string
}

export function RegistrationModal({ isOpen, onClose, source = "register" }: RegistrationModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitResult, setSubmitResult] = useState<{ success: boolean; message: string } | null>(null)
  const initialFocusRef = useRef<HTMLInputElement>(null)

  // Manejar el cierre con la tecla Escape
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose()
      }
    }

    window.addEventListener("keydown", handleEscape)
    return () => window.removeEventListener("keydown", handleEscape)
  }, [isOpen, onClose])

  // Enfocar el primer campo cuando se abre el modal
  useEffect(() => {
    if (isOpen && initialFocusRef.current) {
      setTimeout(() => {
        initialFocusRef.current?.focus()
      }, 100)
    }
  }, [isOpen])

  // Prevenir el scroll cuando el modal está abierto
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "auto"
    }
    return () => {
      document.body.style.overflow = "auto"
    }
  }, [isOpen])

  // Resetear el formulario cuando se cierra el modal
  useEffect(() => {
    if (!isOpen) {
      setFormData({ name: "", email: "" })
      setSubmitResult(null)
    }
  }, [isOpen])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Limpiar mensajes de error cuando el usuario comienza a escribir
    if (submitResult) {
      setSubmitResult(null)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitResult(null)

    try {
      // Validación del lado del cliente
      if (!formData.name.trim()) {
        setSubmitResult({
          success: false,
          message: "Por favor, ingresa tu nombre",
        })
        setIsSubmitting(false)
        return
      }

      if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        setSubmitResult({
          success: false,
          message: "Por favor, ingresa un correo electrónico válido",
        })
        setIsSubmitting(false)
        return
      }

      // Enviar datos al servidor
      const result = await sendContactEmail({
        ...formData,
        source: source,
      })

      setSubmitResult(result)

      if (result.success) {
        // Mostrar mensaje de éxito
        alert(`¡Gracias ${formData.name}! Te contactaremos pronto en ${formData.email}`)
        onClose()
      }
    } catch (error) {
      console.error("Error al enviar el formulario:", error)
      setSubmitResult({
        success: false,
        message: "Ocurrió un error al procesar tu solicitud. Por favor, intenta nuevamente.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          className="fixed inset-0 z-[1001] flex items-center justify-center bg-black/50"
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
        >
          <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center p-5 border-b">
              <h3 id="modal-title" className="text-xl font-semibold text-primary">
                Registrarse
              </h3>
              <button
                onClick={onClose}
                className="text-gray-500 hover:text-gray-700 transition-colors"
                aria-label="Cerrar"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5">
              <div className="mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Nombre completo
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  ref={initialFocusRef}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Ingresa tu nombre"
                  aria-required="true"
                  disabled={isSubmitting}
                />
              </div>

              <div className="mb-6">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Correo electrónico
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Ingresa tu correo electrónico"
                  aria-required="true"
                  disabled={isSubmitting}
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-secondary hover:bg-[#234e39] text-white py-2 px-4 rounded-md font-semibold transition-colors disabled:opacity-70 flex items-center justify-center"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 size={18} className="mr-2 animate-spin" />
                    <span>Enviando...</span>
                  </>
                ) : (
                  "Enviar"
                )}
              </button>

              {submitResult && (
                <div
                  className={`mt-3 text-sm text-center ${submitResult.success ? "text-green-600" : "text-red-500"}`}
                  role="alert"
                >
                  {submitResult.message}
                </div>
              )}
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}

