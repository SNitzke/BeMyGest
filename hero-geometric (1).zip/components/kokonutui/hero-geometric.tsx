<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BeMyGest - Gestión de Alquileres Simplificada</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Open+Sans:wght@400;600&display=swap');
        
        :root {
            --primary: #1a365d;          /* Azul oscuro más formal */
            --secondary: #2d6a4f;        /* Verde oscuro más elegante */
            --dark: #2d3748;             /* Gris oscuro para textos */
            --light: #f7fafc;            /* Blanco hueso para fondos */
            --accent: #c05621;           /* Naranja oscuro para acentos */
            --neutral: #718096;          /* Gris medio para textos secundarios */
            --light-bg: #edf2f7;         /* Gris claro para fondos secundarios */
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: var(--light);
            color: var(--dark);
            line-height: 1.7;
            font-family: 'Open Sans', sans-serif;
        }
        
        h1, h2, h3, h4, h5, h6, .logo, .btn, .nav-links {
            font-family: 'Montserrat', sans-serif;
        }
        
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header Styles */
        header {
            background-color: var(--primary);
            padding: 15px 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
        }
        
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 26px;
            font-weight: 700;
            color: white;
            text-decoration: none;
            letter-spacing: 0.5px;
        }
        
        .logo span {
            color: var(--secondary);
        }
        
        .nav-links {
            display: flex;
            list-style: none;
        }
        
        .nav-links li {
            margin-left: 30px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            font-size: 15px;
            transition: color 0.3s ease;
            letter-spacing: 0.3px;
        }
        
        .nav-links a:hover {
            color: #e2e8f0;
        }
        
        .btn {
            display: inline-block;
            background-color: var(--secondary);
            color: white;
            padding: 10px 22px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            font-size: 15px;
            letter-spacing: 0.3px;
            transition: background-color 0.3s ease;
        }
        
        .btn:hover {
            background-color: #234e39;  /* Verde más oscuro al hover */
        }
        
        /* Hero Section */
        .hero {
            height: 100vh;
            display: flex;
            align-items: center;
            background: linear-gradient(rgba(42, 67, 101, 0.85), rgba(42, 67, 101, 0.85)), url('/api/placeholder/1200/800') center/cover no-repeat;
            color: white;
            text-align: center;
            padding-top: 70px;
        }
        
        .hero-content {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .hero h1 {
            font-size: 3rem;
            margin-bottom: 25px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        
        .hero p {
            font-size: 1.1rem;
            margin-bottom: 35px;
            line-height: 1.7;
        }
        
        /* Features Section */
        .features {
            padding: 90px 0;
            background-color: white;
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 70px;
        }
        
        .section-title h2 {
            font-size: 2.3rem;
            color: var(--primary);
            margin-bottom: 15px;
            font-weight: 700;
            position: relative;
            padding-bottom: 15px;
        }
        
        .section-title h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--secondary);
        }
        
        .section-title p {
            color: var(--neutral);
            max-width: 700px;
            margin: 0 auto;
            font-size: 1.05rem;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 35px;
        }
        
        .feature-card {
            background-color: var(--light-bg);
            border-radius: 8px;
            padding: 35px 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-bottom: 3px solid transparent;
        }
        
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            border-bottom: 3px solid var(--secondary);
        }
        
        .feature-icon {
            font-size: 36px;
            margin-bottom: 25px;
        }
        
        .feature-card h3 {
            font-size: 1.4rem;
            margin-bottom: 15px;
            color: var(--primary);
            font-weight: 600;
        }
        
        /* How It Works Section */
        .how-it-works {
            padding: 90px 0;
            background-color: var(--light-bg);
        }
        
        .steps {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-top: 50px;
        }
        
        .step {
            width: 30%;
            text-align: center;
            position: relative;
        }
        
        .step:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 30px;
            right: -15%;
            width: 30%;
            height: 2px;
            background-color: var(--secondary);
            opacity: 0.5;
        }
        
        .step-number {
            width: 60px;
            height: 60px;
            background-color: var(--primary);
            color: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 22px;
            font-weight: bold;
            margin: 0 auto 25px;
            font-family: 'Montserrat', sans-serif;
        }
        
        .step h3 {
            margin-bottom: 15px;
            color: var(--primary);
            font-size: 1.4rem;
            font-weight: 600;
        }
        
        .step p {
            color: var(--dark);
        }
        
        /* Testimonials Section */
        .testimonials {
            padding: 90px 0;
            background-color: white;
        }
        
        .testimonials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 35px;
        }
        
        .testimonial-card {
            background-color: var(--light-bg);
            border-radius: 8px;
            padding: 35px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
            border-left: 4px solid var(--secondary);
        }
        
        .testimonial-text {
            font-style: italic;
            margin-bottom: 25px;
            position: relative;
            padding-left: 20px;
        }
        
        .testimonial-text::before {
            content: '"';
            font-size: 60px;
            position: absolute;
            left: -15px;
            top: -20px;
            color: var(--secondary);
            opacity: 0.3;
            font-family: Georgia, serif;
        }
        
        .testimonial-author {
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 3px;
        }
        
        .testimonial-role {
            color: var(--neutral);
            font-size: 0.9rem;
        }
        
        /* CTA Section */
        .cta {
            padding: 90px 0;
            background-color: var(--primary);
            color: white;
            text-align: center;
        }
        
        .cta h2 {
            font-size: 2.3rem;
            margin-bottom: 25px;
            font-weight: 700;
        }
        
        .cta p {
            margin-bottom: 35px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            font-size: 1.05rem;
        }
        
        .btn-secondary {
            background-color: white;
            color: var(--primary);
        }
        
        .btn-secondary:hover {
            background-color: #e2e8f0;
        }
        
        /* Footer */
        footer {
            padding: 70px 0 40px;
            background-color: var(--dark);
            color: #a0aec0;
        }
        
        .footer-content {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        
        .footer-column {
            width: 22%;
        }
        
        .footer-column h3 {
            font-size: 1.2rem;
            margin-bottom: 25px;
            color: white;
            font-weight: 600;
            position: relative;
            padding-bottom: 12px;
        }
        
        .footer-column h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 2px;
            background-color: var(--secondary);
        }
        
        .footer-column ul {
            list-style: none;
        }
        
        .footer-column li {
            margin-bottom: 12px;
        }
        
        .footer-column a {
            color: #a0aec0;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.95rem;
        }
        
        .footer-column a:hover {
            color: white;
        }
        
        .copyright {
            text-align: center;
            padding-top: 60px;
            font-size: 0.9rem;
            color: #718096;
        }
        
        /* Responsive Styles */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.3rem;
            }
            
            .step {
                width: 100%;
                margin-bottom: 50px;
            }
            
            .step:not(:last-child)::after {
                display: none;
            }
            
            .footer-column {
                width: 48%;
                margin-bottom: 40px;
            }
            
            .nav-links {
                display: none;
            }
        }
        
        @media (max-width: 480px) {
            .hero h1 {
                font-size: 1.8rem;
            }
            
            .footer-column {
                width: 100%;
            }
            
            .section-title h2 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="#" class="logo">Be<span>My</span>Gest</a>
                <ul class="nav-links">
                    <li><a href="#features">Características</a></li>
                    <li><a href="#how-it-works">Cómo Funciona</a></li>
                    <li><a href="#testimonials">Testimonios</a></li>
                    <li><a href="#contact">Contacto</a></li>
                </ul>
                <a href="#" class="btn">Registrarse</a>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Gestión de Alquileres Simplificada</h1>
                <p>BeMyGest es la solución integral que conecta a propietarios e inquilinos, simplificando pagos, reportes de problemas y comunicación. Gestiona tus propiedades o alquileres de manera eficiente, ahorrando tiempo y reduciendo el estrés.</p>
                <a href="#" class="btn">Comenzar Ahora</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="container">
            <div class="section-title">
                <h2>Características</h2>
                <p>Descubre todas las herramientas que BeMyGest ofrece para simplificar la gestión de tus alquileres</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">💰</div>
                    <h3>Gestión de Pagos</h3>
                    <p>Realiza pagos de renta mediante tarjetas o transferencias bancarias. Recibe recibos automáticos y recordatorios de pago.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔧</div>
                    <h3>Reporte de Problemas</h3>
                    <p>Reporta cualquier tipo de problema adjuntando fotos y videos. Realiza seguimiento del estado de tus reportes.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📞</div>
                    <h3>Directorio de Servicios</h3>
                    <p>Accede a un directorio de proveedores de servicios verificados y califica sus servicios.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">💬</div>
                    <h3>Comunicación</h3>
                    <p>Mensajería interna, notificaciones push y grupos de conversación por inmueble para una comunicación efectiva.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📄</div>
                    <h3>Documentación</h3>
                    <p>Almacena documentos como contratos y recibos, permitiendo su descarga y compartición.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">⭐</div>
                    <h3>Evaluaciones</h3>
                    <p>Sistema de evaluación de 5 estrellas y comentarios para inquilinos y propietarios/administradores.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="how-it-works" id="how-it-works">
        <div class="container">
            <div class="section-title">
                <h2>Cómo Funciona</h2>
                <p>BeMyGest simplifica la gestión de alquileres en tres sencillos pasos</p>
            </div>
            <div class="steps">
                <div class="step">
                    <div class="step-number">1</div>
                    <h3>Regístrate</h3>
                    <p>Crea tu cuenta como propietario o inquilino e ingresa la información de tu propiedad o alquiler.</p>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <h3>Conéctate</h3>
                    <p>Vincula tu cuenta con tus propiedades o alquileres y establece la comunicación con propietarios o inquilinos.</p>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <h3>Gestiona</h3>
                    <p>Realiza pagos, reporta problemas, accede a documentos y comunícate de manera eficiente.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials" id="testimonials">
        <div class="container">
            <div class="section-title">
                <h2>Testimonios</h2>
                <p>Lo que nuestros usuarios dicen sobre BeMyGest</p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Desde que uso BeMyGest, la comunicación con mis inquilinos ha mejorado un 100%. Puedo gestionar todas mis propiedades desde un solo lugar y los pagos siempre llegan a tiempo."
                    </div>
                    <div class="testimonial-author">Carlos Rodríguez</div>
                    <div class="testimonial-role">Propietario de múltiples inmuebles</div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "La función de reporte de problemas es increíble. Puedo enviar fotos del problema y seguir el estado de la reparación. Los recordatorios de pago también son muy útiles."
                    </div>
                    <div class="testimonial-author">María López</div>
                    <div class="testimonial-role">Inquilina</div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        "Como administrador de un edificio, BeMyGest ha simplificado enormemente mi trabajo. Puedo comunicarme con todos los inquilinos a la vez y gestionar los pagos de manera eficiente."
                    </div>
                    <div class="testimonial-author">Juan Pérez</div>
                    <div class="testimonial-role">Administrador de edificio</div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta" id="contact">
        <div class="container">
            <h2>¿Listo para simplificar la gestión de tus alquileres?</h2>
            <p>Únete a BeMyGest hoy y descubre cómo nuestra plataforma puede ayudarte a ahorrar tiempo y reducir el estrés en la gestión de tus propiedades o alquileres.</p>
            <a href="#" class="btn btn-secondary">Registrarse Ahora</a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>BeMyGest</h3>
                    <ul>
                        <li><a href="#">Sobre Nosotros</a></li>
                        <li><a href="#">Términos y Condiciones</a></li>
                        <li><a href="#">Política de Privacidad</a></li>
                        <li><a href="#">Carreras</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Servicios</h3>
                    <ul>
                        <li><a href="#">Para Propietarios</a></li>
                        <li><a href="#">Para Inquilinos</a></li>
                        <li><a href="#">Para Administradores</a></li>
                        <li><a href="#">Directorio de Servicios</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Recursos</h3>
                    <ul>
                        <li><a href="#">Centro de Ayuda</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Guías y Tutoriales</a></li>
                        <li><a href="#">Preguntas Frecuentes</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Contacto</h3>
                    <ul>
                        <li><a href="mailto:info@bemygest.com">info@bemygest.com</a></li>
                        <li><a href="tel:+123456789">+12 345 6789</a></li>
                        <li><a href="#">Formulario de Contacto</a></li>
                        <li><a href="#">Soporte</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                &copy; 2025 BeMyGest. Todos los derechos reservados.
            </div>
        </div>
    </footer>

</body>
</html>

