"use server"

import nodemailer from "nodemailer"

interface FormData {
  name: string
  email: string
  source: string
}

export async function sendContactEmail(formData: FormData) {
  try {
    // Validación de datos
    if (!formData.name || !formData.name.trim()) {
      return { success: false, message: "El nombre es requerido" }
    }

    if (!formData.email || !formData.email.trim() || !isValidEmail(formData.email)) {
      return { success: false, message: "El correo electrónico no es válido" }
    }

    // Configurar el transporte de nodemailer con manejo de errores mejorado
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "bemigest@gmail.com",
        pass: process.env.EMAIL_PASSWORD || "",
      },
      // Aumentar el tiempo de espera para evitar errores de conexión
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 15000,
    })

    // Determinar el asunto según la fuente
    let subject = "Nuevo registro en BeMyGest"
    if (formData.source === "discount") {
      subject = "Nuevo registro con descuento en BeMyGest"
    } else if (formData.source === "hero") {
      subject = "Nuevo registro desde Hero en BeMyGest"
    }

    // Configurar el contenido del correo con sanitización de datos
    const mailOptions = {
      from: "bemigest@gmail.com",
      to: "bemigest@gmail.com",
      subject: subject,
      html: `
        <h1>Nuevo registro en BeMyGest</h1>
        <p><strong>Nombre:</strong> ${sanitizeHtml(formData.name)}</p>
        <p><strong>Correo electrónico:</strong> ${sanitizeHtml(formData.email)}</p>
        <p><strong>Fuente:</strong> ${sanitizeHtml(formData.source)}</p>
        <p><strong>Fecha:</strong> ${new Date().toLocaleString()}</p>
      `,
    }

    // Verificar la conexión antes de enviar
    await new Promise((resolve, reject) => {
      transporter.verify((error, success) => {
        if (error) {
          console.error("Error al verificar el transporte:", error)
          reject(error)
        } else {
          resolve(success)
        }
      })
    })

    // Enviar el correo
    const info = await transporter.sendMail(mailOptions)
    console.log("Correo enviado:", info.messageId)

    return { success: true, message: "Correo enviado correctamente" }
  } catch (error) {
    console.error("Error al enviar el correo:", error)
    return {
      success: false,
      message: "Error al enviar el correo. Por favor, intenta nuevamente más tarde.",
    }
  }
}

// Función para validar el formato del correo electrónico
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Función simple para sanitizar HTML y prevenir inyección
function sanitizeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
}

