import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Montserrat, Open_Sans } from "next/font/google"

const montserrat = Montserrat({
  subsets: ["latin"],
  variable: "--font-montserrat",
  display: "swap",
  weight: ["400", "500", "600", "700"],
})

const openSans = Open_Sans({
  subsets: ["latin"],
  variable: "--font-open-sans",
  display: "swap",
  weight: ["400", "600"],
})

export const metadata: Metadata = {
  title: "BeMyGest - Gestión de Alquileres Simplificada",
  description:
    "BeMyGest es la solución integral que conecta a propietarios e inquilinos, simplificando pagos, reportes de problemas y comunicación.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className={`${montserrat.variable} ${openSans.variable}`}>
      <body>{children}</body>
    </html>
  )
}



import './globals.css'