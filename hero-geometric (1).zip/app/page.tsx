"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Hero } from "@/components/ui/animated-hero"
import { useState, useEffect, useCallback } from "react"
import { RegistrationModal } from "@/components/ui/registration-modal"
import { BenefitsModal } from "@/components/ui/benefits-modal"
import { DiscountModal } from "@/components/ui/discount-modal"
// Importar el componente FAQSection
import { FAQSection } from "@/components/ui/faq-section"

// Datos para los modales de beneficios
const ownerBenefits = {
  title: "Beneficios para Propietarios",
  description:
    "BeMyGest ofrece a los propietarios herramientas poderosas para gestionar sus propiedades de manera eficiente y sin complicaciones.",
  benefits: [
    {
      icon: "💰",
      title: "Gestión de Pagos Simplificada",
      description:
        "Recibe pagos de alquiler a tiempo con recordatorios automáticos y seguimiento de pagos pendientes. Genera recibos automáticamente.",
    },
    {
      icon: "📊",
      title: "Panel de Control Integral",
      description:
        "Visualiza todas tus propiedades, ingresos y gastos en un solo lugar con informes detallados y análisis financieros.",
    },
    {
      icon: "🔔",
      title: "Notificaciones en Tiempo Real",
      description:
        "Recibe alertas instantáneas sobre pagos, problemas reportados o comunicaciones importantes de tus inquilinos.",
    },
    {
      icon: "📝",
      title: "Gestión de Contratos Digital",
      description:
        "Crea, firma y almacena contratos digitalmente. Recibe recordatorios de renovación y vencimiento de contratos.",
    },
    {
      icon: "👥",
      title: "Evaluación de Inquilinos",
      description:
        "Accede a perfiles verificados de inquilinos con historial de pagos y evaluaciones de otros propietarios.",
    },
    {
      icon: "📱",
      title: "Acceso Móvil",
      description:
        "Gestiona tus propiedades desde cualquier lugar con nuestra aplicación móvil intuitiva y fácil de usar.",
    },
  ],
}

const tenantBenefits = {
  title: "Beneficios para Inquilinos",
  description:
    "BeMyGest facilita la vida de los inquilinos con herramientas que mejoran la comunicación y simplifican los procesos cotidianos.",
  benefits: [
    {
      icon: "💳",
      title: "Pagos Digitales Seguros",
      description:
        "Realiza pagos de alquiler de forma segura mediante múltiples métodos de pago y recibe confirmaciones instantáneas.",
    },
    {
      icon: "🔧",
      title: "Reporte de Problemas con Seguimiento",
      description: "Reporta incidencias con fotos y videos, y sigue el estado de la reparación en tiempo real.",
    },
    {
      icon: "📄",
      title: "Acceso a Documentos",
      description:
        "Accede a tu contrato, recibos y otros documentos importantes en cualquier momento desde tu dispositivo.",
    },
    {
      icon: "💬",
      title: "Comunicación Directa",
      description:
        "Comunícate fácilmente con propietarios o administradores a través de nuestro sistema de mensajería integrado.",
    },
    {
      icon: "📅",
      title: "Recordatorios Automáticos",
      description: "Recibe recordatorios de pagos y fechas importantes para evitar recargos por pagos tardíos.",
    },
    {
      icon: "⭐",
      title: "Sistema de Reputación",
      description: "Construye un historial positivo como inquilino que te ayudará en futuros alquileres.",
    },
  ],
}

const managerBenefits = {
  title: "Beneficios para Administradores",
  description:
    "BeMyGest proporciona a los administradores herramientas avanzadas para gestionar múltiples propiedades de manera eficiente.",
  benefits: [
    {
      icon: "🏢",
      title: "Gestión Multi-propiedad",
      description: "Administra múltiples propiedades y edificios desde una sola plataforma con vistas personalizadas.",
    },
    {
      icon: "📈",
      title: "Informes Detallados",
      description: "Genera informes financieros, de ocupación y mantenimiento para propietarios y juntas directivas.",
    },
    {
      icon: "📨",
      title: "Comunicación Masiva",
      description: "Envía notificaciones a todos los inquilinos de un edificio o propiedad con un solo clic.",
    },
    {
      icon: "🔄",
      title: "Automatización de Tareas",
      description: "Automatiza recordatorios, pagos recurrentes y seguimiento de mantenimiento para ahorrar tiempo.",
    },
    {
      icon: "📋",
      title: "Gestión de Proveedores",
      description: "Mantén un directorio de proveedores de servicios confiables y gestiona facturas y pagos.",
    },
    {
      icon: "🔐",
      title: "Control de Acceso",
      description: "Asigna diferentes niveles de acceso a miembros del equipo según sus responsabilidades.",
    },
  ],
}

// Añadir los datos de las preguntas frecuentes después de los datos de beneficios
const faqData = {
  title: "Preguntas Frecuentes",
  description: "Respuestas a las dudas más comunes sobre BeMyGest",
  faqs: [
    {
      question: "¿Cómo funciona BeMyGest para propietarios?",
      answer:
        "Como propietario, BeMyGest te permite gestionar todas tus propiedades desde una plataforma centralizada. Puedes recibir pagos de alquiler, gestionar solicitudes de mantenimiento, comunicarte con tus inquilinos y acceder a documentos importantes. El proceso comienza con un registro sencillo, seguido de la verificación de tu propiedad y la conexión con tus inquilinos actuales o la publicación de propiedades disponibles.",
    },
    {
      question: "¿Cuánto cuesta usar BeMyGest?",
      answer:
        "BeMyGest ofrece diferentes planes según tus necesidades. Contamos con un plan básico gratuito con funcionalidades limitadas, ideal para propietarios con una sola propiedad. Nuestros planes premium comienzan desde $19.99 mensuales, con características adicionales como reportes avanzados, múltiples propiedades y herramientas de análisis financiero. Todos los planes incluyen soporte técnico y actualizaciones regulares.",
    },
    {
      question: "¿Cómo se garantiza la seguridad de mis datos y pagos?",
      answer:
        "La seguridad es nuestra prioridad. Utilizamos encriptación de nivel bancario para proteger todos los datos personales y financieros. Los pagos se procesan a través de pasarelas de pago certificadas y cumplimos con todas las regulaciones de protección de datos. Además, implementamos autenticación de dos factores y monitoreo constante para prevenir accesos no autorizados.",
    },
    {
      question: "¿Puedo usar BeMyGest si soy un inquilino?",
      answer:
        "¡Absolutamente! Como inquilino, BeMyGest te permite realizar pagos de alquiler, reportar problemas de mantenimiento con fotos y videos, comunicarte directamente con tu propietario o administrador, y acceder a todos tus documentos importantes como contratos y recibos. También puedes recibir notificaciones importantes y recordatorios de pagos.",
    },
    {
      question: "¿Qué hago si tengo problemas técnicos con la plataforma?",
      answer:
        "Ofrecemos soporte técnico a través de múltiples canales. Puedes contactarnos por chat en vivo, correo electrónico o teléfono durante horario laboral. También contamos con un extenso centro de ayuda con tutoriales y guías paso a paso. Para problemas urgentes, nuestro equipo de soporte prioritario está disponible para usuarios de planes premium.",
    },
    {
      question: "¿BeMyGest funciona para administradores de múltiples propiedades?",
      answer:
        "BeMyGest está especialmente diseñado para administradores de propiedades múltiples. Nuestra plataforma permite gestionar edificios completos o carteras de propiedades, con herramientas específicas para comunicación masiva, reportes consolidados, gestión de mantenimiento y seguimiento financiero. Los planes para administradores incluyen funcionalidades avanzadas como asignación de roles y permisos para tu equipo.",
    },
    {
      question: "¿Cómo se manejan los depósitos de garantía?",
      answer:
        "BeMyGest facilita la gestión transparente de depósitos de garantía. La plataforma permite documentar el estado de la propiedad al inicio del contrato con fotos y videos, registrar el monto del depósito, y establecer las condiciones para su devolución. Al finalizar el contrato, el sistema guía el proceso de inspección y devolución, manteniendo un registro detallado para evitar disputas.",
    },
    {
      question: "¿Puedo integrar BeMyGest con otros servicios que ya utilizo?",
      answer:
        "Sí, BeMyGest ofrece integraciones con múltiples servicios populares. Puedes conectar tu cuenta bancaria, servicios de contabilidad como QuickBooks o Xero, calendarios, y plataformas de firma electrónica. También contamos con una API para desarrolladores que permite crear integraciones personalizadas con tus sistemas existentes.",
    },
  ],
}

// Tipos para los modales
type ModalType = "register" | "hero" | "discount" | "owner" | "tenant" | "manager" | null

function HeroDemo({ onStartNowClick }: { onStartNowClick: () => void }) {
  return (
    <div className="block">
      <Hero onStartNowClick={onStartNowClick} />
    </div>
  )
}

export default function LandingPage() {
  // Estado unificado para modales
  const [activeModal, setActiveModal] = useState<ModalType>(null)
  const [hasShownDiscount, setHasShownDiscount] = useState(false)

  // Verificar si ya se ha mostrado el descuento en esta sesión
  useEffect(() => {
    const hasShown = sessionStorage.getItem("hasShownDiscount")
    if (hasShown) {
      setHasShownDiscount(true)
    }
  }, [])

  // Mostrar el modal de descuento después de 10 segundos
  useEffect(() => {
    if (!hasShownDiscount) {
      const timer = setTimeout(() => {
        setActiveModal("discount")
        setHasShownDiscount(true)
        // Guardar en sessionStorage para que no se muestre nuevamente en esta sesión
        sessionStorage.setItem("hasShownDiscount", "true")
      }, 10000) // 10 segundos

      return () => clearTimeout(timer)
    }
  }, [hasShownDiscount])

  // Funciones para abrir y cerrar modales
  const openModal = useCallback((type: ModalType) => {
    setActiveModal(type)
  }, [])

  const closeModal = useCallback(() => {
    setActiveModal(null)
  }, [])

  return (
    <>
      {/* Registration Modal */}
      <RegistrationModal
        isOpen={activeModal === "register" || activeModal === "hero"}
        onClose={closeModal}
        source={activeModal === "hero" ? "hero" : "register"}
      />

      {/* Discount Modal */}
      <DiscountModal isOpen={activeModal === "discount"} onClose={closeModal} />

      {/* Benefits Modals */}
      <BenefitsModal
        isOpen={activeModal === "owner"}
        onClose={closeModal}
        title={ownerBenefits.title}
        description={ownerBenefits.description}
        benefits={ownerBenefits.benefits}
      />

      <BenefitsModal
        isOpen={activeModal === "tenant"}
        onClose={closeModal}
        title={tenantBenefits.title}
        description={tenantBenefits.description}
        benefits={tenantBenefits.benefits}
      />

      <BenefitsModal
        isOpen={activeModal === "manager"}
        onClose={closeModal}
        title={managerBenefits.title}
        description={managerBenefits.description}
        benefits={managerBenefits.benefits}
      />

      {/* Header */}
      <header className="fixed w-full top-0 z-[1000] bg-primary shadow-md">
        <div className="container mx-auto px-5">
          <nav className="flex justify-between items-center py-4">
            <Link href="/" className="text-2xl font-bold text-white tracking-wide">
              Be<span className="text-secondary">My</span>Gest
            </Link>
            <ul className="hidden md:flex list-none">
              <li className="ml-8">
                <Link
                  href="#features"
                  className="text-white hover:text-gray-200 font-medium text-sm tracking-wide transition-colors"
                >
                  Características
                </Link>
              </li>
              <li className="ml-8">
                <Link
                  href="#how-it-works"
                  className="text-white hover:text-gray-200 font-medium text-sm tracking-wide transition-colors"
                >
                  Cómo Funciona
                </Link>
              </li>
              <li className="ml-8">
                <Link
                  href="#testimonials"
                  className="text-white hover:text-gray-200 font-medium text-sm tracking-wide transition-colors"
                >
                  Testimonios
                </Link>
              </li>
              <li className="ml-8">
                <Link
                  href="#contact"
                  className="text-white hover:text-gray-200 font-medium text-sm tracking-wide transition-colors"
                >
                  Contacto
                </Link>
              </li>
            </ul>
            <button
              onClick={() => openModal("register")}
              className="bg-secondary hover:bg-[#234e39] text-white px-5 py-2 rounded font-semibold text-sm tracking-wide transition-colors"
            >
              Registrarse
            </button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <HeroDemo onStartNowClick={() => openModal("hero")} />

      {/* Property Showcase Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-5">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Propiedades Destacadas</h2>
            <p className="text-neutral-600 max-w-2xl mx-auto">
              Descubre espacios excepcionales que se adaptan a tu estilo de vida
            </p>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
          >
            <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_SHB4ZsHT_1741019088652_raw.jpg-gMiUKJ04Nu7mFsDIYfHAJMqPzIBiGb.jpeg"
                alt="Propiedades modernas disponibles"
                fill
                className="object-cover hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent">
                <div className="absolute bottom-6 left-6 text-white">
                  <h3 className="text-xl font-semibold mb-2">Residencias Modernas</h3>
                  <p className="text-sm">Diseño contemporáneo con máxima comodidad</p>
                </div>
              </div>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_T58VMF-b_1741019088899_raw.jpg-uSVRgYrMot7bYK62LQAQekoqRvYOyA.jpeg"
                alt="Casas exclusivas en venta"
                fill
                className="object-cover hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent">
                <div className="absolute bottom-6 left-6 text-white">
                  <h3 className="text-xl font-semibold mb-2">Espacios Exclusivos</h3>
                  <p className="text-sm">Propiedades únicas para familias exigentes</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Professional Services Section */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-5">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Servicio Profesional Garantizado</h2>
            <p className="text-neutral-600 max-w-2xl mx-auto">
              Nuestro equipo de expertos está comprometido con tu satisfacción
            </p>
          </div>

          {/* Tres apartados para los diferentes tipos de usuarios */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="group cursor-pointer"
              onClick={() => openModal("owner")}
            >
              <div className="relative h-[300px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_v0rCzyUN_1741021131447_raw.jpg-JMvbefpjTyr0bx50JqvJ3hIcT5h1X4.jpeg"
                  alt="Servicios para propietarios"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent group-hover:from-primary/80 transition-all duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="text-xl font-semibold text-white mb-2">Para Propietarios</h3>
                    <p className="text-white/80 text-sm mb-4">
                      Descubre cómo BeMyGest puede ayudarte a gestionar tus propiedades
                    </p>
                    <span className="inline-block px-4 py-2 bg-secondary text-white rounded text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      Ver beneficios
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="group cursor-pointer"
              onClick={() => openModal("tenant")}
            >
              <div className="relative h-[300px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_pp6o8PYj_1741021131303_raw.jpg-qtQq5THi6GNoLminc35v6AJuOyz49J.jpeg"
                  alt="Servicios para inquilinos"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent group-hover:from-primary/80 transition-all duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="text-xl font-semibold text-white mb-2">Para Inquilinos</h3>
                    <p className="text-white/80 text-sm mb-4">
                      Simplifica tu experiencia como inquilino con nuestras herramientas
                    </p>
                    <span className="inline-block px-4 py-2 bg-secondary text-white rounded text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      Ver beneficios
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="group cursor-pointer"
              onClick={() => openModal("manager")}
            >
              <div className="relative h-[300px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_B7aWt8kd_1741021417284_raw.jpg-51G4yyniw4jdH1R3SkTYRJYxp14rrL.jpeg"
                  alt="Servicios para administradores"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent group-hover:from-primary/80 transition-all duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="text-xl font-semibold text-white mb-2">Para Administradores</h3>
                    <p className="text-white/80 text-sm mb-4">
                      Gestiona múltiples propiedades con eficiencia y control total
                    </p>
                    <span className="inline-block px-4 py-2 bg-secondary text-white rounded text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      Ver beneficios
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Contenido adicional de la sección */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h3 className="text-2xl font-semibold text-primary mb-4">Soluciones adaptadas a tus necesidades</h3>
            <p className="text-neutral-600 max-w-2xl mx-auto mb-8">
              Nuestro equipo de expertos está listo para ayudarte a sacar el máximo provecho de BeMyGest,
              independientemente de tu rol en el proceso de alquiler.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white">
        <div className="container mx-auto px-5">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-primary font-bold mb-4 pb-4 relative inline-block">
              Características
              <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-[3px] bg-secondary"></span>
            </h2>
            <p className="text-neutral max-w-[700px] mx-auto text-lg">
              Descubre todas las herramientas que BeMyGest ofrece para simplificar la gestión de tus alquileres
            </p>
          </div>

          {/* Feature Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-9">
            <FeatureCard
              icon="💰"
              title="Gestión de Pagos"
              description="Realiza pagos de renta mediante tarjetas o transferencias bancarias. Recibe recibos automáticos y recordatorios de pago."
            />
            <FeatureCard
              icon="🔧"
              title="Reporte de Problemas"
              description="Reporta cualquier tipo de problema adjuntando fotos y videos. Realiza seguimiento del estado de tus reportes."
            />
            <FeatureCard
              icon="📞"
              title="Directorio de Servicios"
              description="Accede a un directorio de proveedores de servicios verificados y califica sus servicios."
            />
            <FeatureCard
              icon="💬"
              title="Comunicación"
              description="Mensajería interna, notificaciones push y grupos de conversación por inmueble para una comunicación efectiva."
            />
            <FeatureCard
              icon="📄"
              title="Documentación"
              description="Almacena documentos como contratos y recibos, permitiendo su descarga y compartición."
            />
            <FeatureCard
              icon="⭐"
              title="Evaluaciones"
              description="Sistema de evaluación de 5 estrellas y comentarios para inquilinos y propietarios/administradores."
            />
          </div>
        </div>
      </section>

      {/* Client Success Stories */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-5">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Historias de Éxito</h2>
            <p className="text-neutral-600 max-w-2xl mx-auto">
              Descubre cómo BeMyGest ha transformado la experiencia de nuestros clientes
            </p>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16"
          >
            <div className="grid gap-4">
              <div className="relative h-[250px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_B7aWt8kd_1741021417284_raw.jpg-51G4yyniw4jdH1R3SkTYRJYxp14rrL.jpeg"
                  alt="Momentos felices"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="relative h-[250px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_XmoTIj_d_1741021417290_raw.jpg-ZnyGviM1Mkc2L0UFnxvf97DKMEv7kk.jpeg"
                  alt="Experiencias compartidas"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
            <div className="relative h-[520px] rounded-lg overflow-hidden shadow-lg">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_QZGPDa6B_1741021417965_raw.jpg-yi1oc2jCa4Y2AHcjgKcvRStaN4n8J4.jpeg"
                alt="Comunidad BeMyGest"
                fill
                className="object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 bg-white">
        <div className="container mx-auto px-5">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-primary font-bold mb-4 pb-4 relative inline-block">
              Cómo Funciona
              <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-[3px] bg-secondary"></span>
            </h2>
            <p className="text-neutral max-w-[700px] mx-auto text-lg">
              BeMyGest simplifica la gestión de alquileres en tres sencillos pasos
            </p>
          </div>

          {/* Professional Interaction Gallery */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16"
          >
            <div className="grid gap-4">
              <div className="relative h-[250px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_T58VMF-b_1741019088899_raw.jpg-ulRYUccFLHzRIil7UdYcwMDb3QII8p.jpeg"
                  alt="Consulta profesional"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="relative h-[250px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_v0rCzyUN_1741021131447_raw.jpg-ovOYAnCB2EPYXPCwDjCp6unV4QLI8G.jpeg"
                  alt="Asesoramiento personalizado"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
            <div className="relative h-[520px] rounded-lg overflow-hidden shadow-lg">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_pp6o8PYj_1741021131303_raw.jpg-d8CGCZo0TrBVjJJJc7HPxNv0mbnK0i.jpeg"
                alt="Experiencia del cliente"
                fill
                className="object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
          </motion.div>

          <div className="flex flex-col md:flex-row justify-between mt-12">
            <Step
              number="1"
              title="Regístrate"
              description="Crea tu cuenta como propietario o inquilino e ingresa la información de tu propiedad o alquiler."
              isLast={false}
            />
            <Step
              number="2"
              title="Conéctate"
              description="Vincula tu cuenta con tus propiedades o alquileres y establece la comunicación con propietarios o inquilinos."
              isLast={false}
            />
            <Step
              number="3"
              title="Gestiona"
              description="Realiza pagos, reporta problemas, accede a documentos y comunícate de manera eficiente."
              isLast={true}
            />
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-white">
        <div className="container mx-auto px-5">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-primary font-bold mb-4 pb-4 relative inline-block">
              Testimonios
              <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-[3px] bg-secondary"></span>
            </h2>
            <p className="text-neutral max-w-[700px] mx-auto text-lg">Lo que nuestros usuarios dicen sobre BeMyGest</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-9">
            <TestimonialCard
              quote="Desde que uso BeMyGest, la comunicación con mis inquilinos ha mejorado un 100%. Puedo gestionar todas mis propiedades desde un solo lugar y los pagos siempre llegan a tiempo."
              author="Carlos Rodríguez"
              role="Propietario de múltiples inmuebles"
            />
            <TestimonialCard
              quote="La función de reporte de problemas es increíble. Puedo enviar fotos del problema y seguir el estado de la reparación. Los recordatorios de pago también son muy útiles."
              author="María López"
              role="Inquilina"
            />
            <TestimonialCard
              quote="Como administrador de un edificio, BeMyGest ha simplificado enormemente mi trabajo. Puedo comunicarme con todos los inquilinos a la vez y gestionar los pagos de manera eficiente."
              author="Juan Pérez"
              role="Administrador de edificio"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-24 bg-primary text-white">
        <div className="container mx-auto px-5">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16"
          >
            <div className="relative h-[300px] rounded-lg overflow-hidden shadow-lg">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_SHB4ZsHT_1741019088652_raw.jpg-gMiUKJ04Nu7mFsDIYfHAJMqPzIBiGb.jpeg"
                alt="Propiedades disponibles"
                fill
                className="object-cover hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/30"></div>
            </div>
            <div className="relative h-[300px] rounded-lg overflow-hidden shadow-lg">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/openart-image_T58VMF-b_1741019088899_raw.jpg-uSVRgYrMot7bYK62LQAQekoqRvYOyA.jpeg"
                alt="Gestión profesional"
                fill
                className="object-cover hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/30"></div>
            </div>
          </motion.div>

          <div className="text-center">
            <h2 className="text-4xl font-bold mb-6">¿Listo para simplificar la gestión de tus alquileres?</h2>
            <p className="mb-9 max-w-[700px] mx-auto text-lg">
              Únete a BeMyGest hoy y descubre cómo nuestra plataforma puede ayudarte a ahorrar tiempo y reducir el
              estrés en la gestión de tus propiedades o alquileres.
            </p>
            <button
              onClick={() => openModal("register")}
              className="bg-white text-primary hover:bg-gray-200 px-5 py-3 rounded font-semibold text-sm tracking-wide transition-colors"
            >
              Registrarse Ahora
            </button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection id="faq" title={faqData.title} description={faqData.description} faqs={faqData.faqs} />

      {/* Footer */}
      <footer className="pt-20 pb-10 bg-dark text-[#a0aec0]">
        <div className="container mx-auto px-5">
          <div className="flex flex-wrap justify-between">
            <FooterColumn
              title="BeMyGest"
              links={[
                { text: "Sobre Nosotros", href: "#" },
                { text: "Términos y Condiciones", href: "#" },
                { text: "Política de Privacidad", href: "#" },
                { text: "Carreras", href: "#" },
              ]}
            />
            <FooterColumn
              title="Servicios"
              links={[
                { text: "Para Propietarios", href: "#", onClick: () => openModal("owner") },
                { text: "Para Inquilinos", href: "#", onClick: () => openModal("tenant") },
                { text: "Para Administradores", href: "#", onClick: () => openModal("manager") },
                { text: "Directorio de Servicios", href: "#" },
              ]}
            />
            <FooterColumn
              title="Recursos"
              links={[
                { text: "Centro de Ayuda", href: "#" },
                { text: "Blog", href: "#" },
                { text: "Guías y Tutoriales", href: "#" },
                { text: "Preguntas Frecuentes", href: "#faq" },
              ]}
            />
            <FooterColumn
              title="Contacto"
              links={[
                { text: "bemigest@gmail.com", href: "mailto:bemigest@gmail.com" },
                { text: "+525564259421", href: "tel:+525564259421" },
                { text: "Formulario de Contacto", href: "#" },
                { text: "Soporte", href: "#" },
              ]}
            />
          </div>
          <div className="text-center pt-16 text-sm text-[#718096]">
            &copy; 2025 BeMyGest. Todos los derechos reservados.
          </div>
        </div>
      </footer>
    </>
  )
}

// Component for feature cards
function FeatureCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div className="bg-light-bg rounded-lg p-8 shadow-md transition-all duration-300 border-b-[3px] border-transparent hover:transform hover:-translate-y-2 hover:shadow-lg hover:border-secondary">
      <div className="text-4xl mb-6">{icon}</div>
      <h3 className="text-xl text-primary font-semibold mb-4">{title}</h3>
      <p className="text-dark">{description}</p>
    </div>
  )
}

// Component for steps
function Step({
  number,
  title,
  description,
  isLast,
}: { number: string; title: string; description: string; isLast: boolean }) {
  return (
    <div className="w-full md:w-[30%] text-center relative mb-12 md:mb-0">
      {!isLast && (
        <div className="hidden md:block absolute top-[30px] right-[-15%] w-[30%] h-[2px] bg-secondary opacity-50"></div>
      )}
      <div className="w-[60px] h-[60px] bg-primary text-white rounded-full flex justify-center items-center text-2xl font-bold mx-auto mb-6 font-montserrat">
        {number}
      </div>
      <h3 className="text-xl text-primary font-semibold mb-4">{title}</h3>
      <p className="text-dark">{description}</p>
    </div>
  )
}

// Component for testimonial cards
function TestimonialCard({ quote, author, role }: { quote: string; author: string; role: string }) {
  return (
    <div className="bg-light-bg rounded-lg p-9 shadow-md border-l-4 border-secondary">
      <div className="italic mb-6 relative pl-5">
        <span className="absolute left-[-15px] top-[-20px] text-6xl text-secondary opacity-30 font-serif">"</span>
        {quote}
      </div>
      <div className="font-semibold text-primary mb-1">{author}</div>
      <div className="text-neutral text-sm">{role}</div>
    </div>
  )
}

// Component for footer columns
function FooterColumn({
  title,
  links,
}: { title: string; links: { text: string; href: string; onClick?: () => void }[] }) {
  return (
    <div className="w-full sm:w-[48%] lg:w-[22%] mb-10">
      <h3 className="text-lg text-white font-semibold mb-6 pb-3 relative">
        {title}
        <span className="absolute bottom-0 left-0 w-10 h-[2px] bg-secondary"></span>
      </h3>
      <ul className="list-none">
        {links.map((link, index) => (
          <li key={index} className="mb-3">
            {link.onClick ? (
              <button
                onClick={link.onClick}
                className="text-[#a0aec0] hover:text-white text-sm transition-colors text-left"
              >
                {link.text}
              </button>
            ) : (
              <Link href={link.href} className="text-[#a0aec0] hover:text-white text-sm transition-colors">
                {link.text}
              </Link>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}

